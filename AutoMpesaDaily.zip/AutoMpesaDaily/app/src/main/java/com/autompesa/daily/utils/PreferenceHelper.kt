package com.autompesa.daily.utils

import android.content.Context
import android.content.SharedPreferences
import com.autompesa.daily.config.MpesaConfig

/**
 * Helper class for managing SharedPreferences
 */
class PreferenceHelper(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        MpesaConfig.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    // Boolean methods
    fun saveBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    fun getBoolean(key: String, defaultValue: Boolean = false): Boolean {
        return prefs.getBoolean(key, defaultValue)
    }

    // Integer methods
    fun saveInt(key: String, value: Int) {
        prefs.edit().putInt(key, value).apply()
    }

    fun getInt(key: String, defaultValue: Int = 0): Int {
        return prefs.getInt(key, defaultValue)
    }

    // Long methods
    fun saveLong(key: String, value: Long) {
        prefs.edit().putLong(key, value).apply()
    }

    fun getLong(key: String, defaultValue: Long = 0): Long {
        return prefs.getLong(key, defaultValue)
    }

    // String methods
    fun saveString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun getString(key: String, defaultValue: String = ""): String {
        return prefs.getString(key, defaultValue) ?: defaultValue
    }

    // Service status methods (using MpesaConfig keys)
    fun isServiceEnabled(): Boolean {
        return getBoolean(MpesaConfig.KEY_IS_ENABLED, false)
    }

    fun setServiceEnabled(enabled: Boolean) {
        saveBoolean(MpesaConfig.KEY_IS_ENABLED, enabled)
    }

    fun setLastSentTime(time: Long) {
        saveLong(MpesaConfig.KEY_LAST_SENT, time)
    }

    fun getLastSentTime(): Long {
        return getLong(MpesaConfig.KEY_LAST_SENT, 0)
    }

    fun addToTotalSent(amount: Int) {
        val current = getInt(MpesaConfig.KEY_TOTAL_SENT, 0)
        saveInt(MpesaConfig.KEY_TOTAL_SENT, current + amount)
    }

    fun getTotalSent(): Int {
        return getInt(MpesaConfig.KEY_TOTAL_SENT, 0)
    }

    // Clear all preferences (for testing/reset)
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}